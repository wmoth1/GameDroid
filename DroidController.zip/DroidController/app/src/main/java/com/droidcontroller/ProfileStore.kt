package com.droidcontroller

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Built-in layouts. Positions are fractions of the screen, sizes are fractions of screen height. */
object Layouts {
    private fun c(
        id: String, kind: Kind, x: Float, y: Float, size: Float,
        out: String = id, visible: Boolean = true
    ) = Control(id, kind, x, y, size, visible, out)

    /** Inputs that are not drawn: tilt and the volume keys. Off until the user maps them. */
    private fun physical() = listOf(
        c("TILT_X", Kind.AXIS, 0f, 0f, 0f, "OFF", false),
        c("TILT_Y", Kind.AXIS, 0f, 0f, 0f, "OFF", false),
        c("VOL_UP", Kind.KEY, 0f, 0f, 0f, "OFF", false),
        c("VOL_DOWN", Kind.KEY, 0f, 0f, 0f, "OFF", false)
    )

    /** A full gamepad. [symmetric] = PlayStation style (sticks side by side at the bottom). */
    fun gamepad(symmetric: Boolean): List<Control> = listOf(
        c("LT", Kind.BUTTON, .085f, .12f, .08f),
        c("LB", Kind.BUTTON, .085f, .30f, .08f),
        c("RT", Kind.BUTTON, .915f, .12f, .08f),
        c("RB", Kind.BUTTON, .915f, .30f, .08f),
        c("VIEW", Kind.BUTTON, .42f, .14f, .05f),
        c("GUIDE", Kind.BUTTON, .50f, .14f, .05f),
        c("MENU", Kind.BUTTON, .58f, .14f, .05f),
        c("LS", Kind.BUTTON, .44f, .40f, .05f),
        c("RS", Kind.BUTTON, .56f, .40f, .05f),
        c("NORTH", Kind.BUTTON, .800f, .41f, .085f),
        c("SOUTH", Kind.BUTTON, .800f, .71f, .085f),
        c("WEST", Kind.BUTTON, .732f, .56f, .085f),
        c("EAST", Kind.BUTTON, .868f, .56f, .085f),
        if (symmetric) c("STICK_L", Kind.STICK, .38f, .76f, .17f, "STICK_LEFT")
        else c("STICK_L", Kind.STICK, .20f, .56f, .17f, "STICK_LEFT"),
        if (symmetric) c("DPAD", Kind.DPAD, .20f, .56f, .15f, "DPAD")
        else c("DPAD", Kind.DPAD, .38f, .78f, .15f, "DPAD"),
        if (symmetric) c("STICK_R", Kind.STICK, .62f, .76f, .17f, "STICK_RIGHT")
        else c("STICK_R", Kind.STICK, .62f, .78f, .17f, "STICK_RIGHT"),
        // Extra buttons, hidden until you show them in the editor.
        c("TURBO", Kind.BUTTON, .32f, .14f, .05f, "TURBO", false),
        c("M1", Kind.BUTTON, .60f, .26f, .04f, "MACRO1", false),
        c("M2", Kind.BUTTON, .66f, .26f, .04f, "MACRO2", false),
        c("M3", Kind.BUTTON, .72f, .26f, .04f, "MACRO3", false),
        c("M4", Kind.BUTTON, .78f, .26f, .04f, "MACRO4", false)
    ) + physical()

    /** Almost empty screen: tilt steers, left/right pedals are brake and gas, volume keys are A and B. */
    fun racing(): List<Control> = gamepad(false).map {
        when (it.id) {
            "LT" -> it.copy(x = .14f, y = .55f, size = .20f)
            "RT" -> it.copy(x = .86f, y = .55f, size = .20f)
            "TILT_X" -> it.copy(out = "AX_LX")
            "VOL_UP" -> it.copy(out = "SOUTH")
            "VOL_DOWN" -> it.copy(out = "EAST")
            else -> it.copy(visible = false)
        }
    }

    val names = listOf("Xbox", "PlayStation", "Switch", "Racing (tilt)")

    fun builtin(name: String): Profile? = when (name) {
        "Xbox" -> Profile(name, Skin.XBOX, gamepad(false))
        "PlayStation" -> Profile(name, Skin.PLAYSTATION, gamepad(true))
        "Switch" -> Profile(name, Skin.SWITCH, gamepad(false))
        "Racing (tilt)" -> Profile(name, Skin.XBOX, racing())
        else -> null
    }
}

/** Saves profiles as JSON in SharedPreferences. Built-in profiles are created on first run. */
class ProfileStore(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("droidcontroller", Context.MODE_PRIVATE)

    var current: String
        get() = sp.getString("current", "Xbox") ?: "Xbox"
        set(v) { sp.edit().putString("current", v).apply() }

    fun isBuiltin(name: String) = name in Layouts.names
    fun defaultFor(name: String): Profile? = Layouts.builtin(name)

    fun all(): List<Profile> {
        val raw = sp.getString("profiles2", null)
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                // "PC (keyboard + mouse)" belonged to an earlier version that is gone now.
                val list = (0 until arr.length())
                    .mapNotNull { runCatching { fromJson(arr.getJSONObject(it)) }.getOrNull() }
                    .filter { it.name != "PC (keyboard + mouse)" }
                if (list.isNotEmpty()) return list
            } catch (_: Exception) { }
        }
        return Layouts.names.mapNotNull { Layouts.builtin(it) }.also { saveAll(it) }
    }

    fun get(name: String): Profile = all().let { l -> l.firstOrNull { it.name == name } ?: l.first() }

    fun upsert(p: Profile) {
        val l = all().toMutableList()
        val i = l.indexOfFirst { it.name == p.name }
        if (i >= 0) l[i] = p else l.add(p)
        saveAll(l)
    }

    fun delete(name: String) {
        saveAll(all().filter { it.name != name }) // if empty, all() restores the built-ins
        if (current == name) current = all().first().name
    }

    private fun saveAll(list: List<Profile>) {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        sp.edit().putString("profiles2", arr.toString()).apply()
    }

    private fun toJson(p: Profile) = JSONObject().apply {
        put("name", p.name)
        put("skin", p.skin.name)
        put("controls", JSONArray().also { a ->
            p.controls.forEach {
                a.put(JSONObject().put("id", it.id).put("k", it.kind.name)
                    .put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("s", it.size.toDouble())
                    .put("v", it.visible).put("o", it.out))
            }
        })
    }

    private fun fromJson(o: JSONObject): Profile {
        val defaults = Layouts.gamepad(false).associateBy { it.id }
        val controls = ArrayList<Control>()
        val ca = o.getJSONArray("controls")
        for (i in 0 until ca.length()) {
            val c = ca.getJSONObject(i)
            runCatching { // controls of removed kinds (the touchpad) fail to parse and are skipped
                val kind = Kind.valueOf(c.getString("k"))
                var out = c.getString("o")
                if (!Outputs.isValid(kind, out)) out = defaults[c.getString("id")]?.out ?: "OFF" // old keyboard/mouse outputs
                controls.add(Control(c.getString("id"), kind,
                    c.getDouble("x").toFloat(), c.getDouble("y").toFloat(), c.getDouble("s").toFloat(),
                    c.getBoolean("v"), out))
            }
        }
        // Make sure every control exists (hidden if it was missing), so the editor can always show it.
        val have = controls.map { it.id }.toSet()
        defaults.values.filter { it.id !in have }.forEach { controls.add(it.copy(visible = false)) }
        val skin = runCatching { Skin.valueOf(o.getString("skin")) }.getOrDefault(Skin.XBOX)
        return Profile(o.getString("name"), skin, controls)
    }
}
