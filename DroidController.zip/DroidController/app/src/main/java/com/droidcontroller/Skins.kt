package com.droidcontroller

/** Colours and style of one skin. Hollow skins draw outlines only, glow skins add a soft halo. */
class Theme(
    val bg: Int,
    val body: Int,
    val panel: Int,
    val knob: Int,
    val outline: Int,
    val text: Int,
    val hollow: Boolean,
    val glow: Boolean
)

/** Labels and colours that make the on-screen pad look like Xbox, PlayStation, Switch, SNES, Neon, Minimal or Terminal. */
object Skins {
    private val WHITE = 0xFFFFFFFF.toInt()

    private val STANDARD = Theme(0xFF111114.toInt(), 0xFF3A3A42.toInt(), 0xFF1E1E24.toInt(),
        0xFF55555E.toInt(), 0x66FFFFFF, WHITE, hollow = false, glow = false)
    private val RETRO = Theme(0xFFB9B6C6.toInt(), 0xFF55526A.toInt(), 0xFF3F3D52.toInt(),
        0xFF6E6B85.toInt(), 0xFF2A2938.toInt(), WHITE, hollow = false, glow = false)
    private val NEON = Theme(0xFF07070F.toInt(), 0xFF14142A.toInt(), 0xFF0B0B18.toInt(),
        0xFF1B1B3A.toInt(), 0xFF00E5FF.toInt(), WHITE, hollow = true, glow = true)
    private val MINIMAL = Theme(0xFF000000.toInt(), 0xFF000000.toInt(), 0xFF000000.toInt(),
        0xFF2A2A2A.toInt(), WHITE, WHITE, hollow = true, glow = false)
    private val TERMINAL = Theme(0xFF020A04.toInt(), 0xFF020A04.toInt(), 0xFF04120A.toInt(),
        0xFF0E3B1A.toInt(), 0xFF33FF66.toInt(), 0xFF33FF66.toInt(), hollow = true, glow = true)

    fun theme(skin: Skin): Theme = when (skin) {
        Skin.RETRO -> RETRO
        Skin.NEON -> NEON
        Skin.MINIMAL -> MINIMAL
        Skin.TERMINAL -> TERMINAL
        else -> STANDARD
    }

    fun title(skin: Skin): String = when (skin) {
        Skin.XBOX -> "Xbox"
        Skin.PLAYSTATION -> "PlayStation"
        Skin.SWITCH -> "Nintendo Switch"
        Skin.RETRO -> "Retro (SNES)"
        Skin.NEON -> "Neon"
        Skin.MINIMAL -> "Minimal"
        Skin.TERMINAL -> "Terminal"
    }

    fun label(skin: Skin, b: Btn): String = when (b) {
        Btn.SOUTH -> pick(skin, "A", "✕", "B")
        Btn.EAST -> pick(skin, "B", "○", "A")
        Btn.WEST -> pick(skin, "X", "□", "Y")
        Btn.NORTH -> pick(skin, "Y", "△", "X")
        Btn.LB -> pick(skin, "LB", "L1", "L")
        Btn.RB -> pick(skin, "RB", "R1", "R")
        Btn.VIEW -> pick(skin, "VIEW", "CREATE", "−", "SELECT")
        Btn.MENU -> pick(skin, "MENU", "OPTIONS", "+", "START")
        Btn.GUIDE -> pick(skin, "XBOX", "PS", "HOME")
        Btn.LS -> "L3"
        Btn.RS -> "R3"
    }

    fun trigger(skin: Skin, left: Boolean): String =
        if (left) pick(skin, "LT", "L2", "ZL", "L2") else pick(skin, "RT", "R2", "ZR", "R2")

    fun isFace(b: Btn) = b == Btn.SOUTH || b == Btn.EAST || b == Btn.WEST || b == Btn.NORTH

    /** Colour of a button that is not a face button. */
    fun plain(skin: Skin): Int = theme(skin).let { if (it.hollow) it.outline else it.body }

    fun color(skin: Skin, b: Btn): Int {
        if (!isFace(b)) return plain(skin)
        return when (skin) {
            Skin.XBOX -> when (b) {
                Btn.SOUTH -> 0xFF3FA34D.toInt()
                Btn.EAST -> 0xFFD0393E.toInt()
                Btn.WEST -> 0xFF2F6FD6.toInt()
                else -> 0xFFE0B02A.toInt()
            }
            Skin.PLAYSTATION -> when (b) {
                Btn.SOUTH -> 0xFF5B8DEF.toInt()
                Btn.EAST -> 0xFFE5484D.toInt()
                Btn.WEST -> 0xFFD981BD.toInt()
                else -> 0xFF3DD6A0.toInt()
            }
            Skin.SWITCH -> 0xFF8E8E96.toInt()
            Skin.RETRO -> when (b) { // SNES: B yellow, A red, Y green, X blue
                Btn.SOUTH -> 0xFFE0B02A.toInt()
                Btn.EAST -> 0xFFD0393E.toInt()
                Btn.WEST -> 0xFF3FA34D.toInt()
                else -> 0xFF2F6FD6.toInt()
            }
            Skin.NEON -> when (b) {
                Btn.SOUTH -> 0xFF39FF14.toInt()
                Btn.EAST -> 0xFFFF2E63.toInt()
                Btn.WEST -> 0xFF00E5FF.toInt()
                else -> 0xFFFFE600.toInt()
            }
            Skin.MINIMAL -> WHITE
            Skin.TERMINAL -> 0xFF33FF66.toInt()
        }
    }

    private fun pick(skin: Skin, xbox: String, ps: String, sw: String, retro: String = sw) = when (skin) {
        Skin.PLAYSTATION -> ps
        Skin.SWITCH -> sw
        Skin.RETRO -> retro
        else -> xbox
    }
}
