package com.droidcontroller

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

enum class PressAnim(val title: String) {
    NONE("None"), SHRINK("Shrink"), GLOW("Glow"), RIPPLE("Ripple"), BOUNCE("Bounce")
}

/** App-wide options, saved as you change them. */
class Settings(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("droidcontroller", Context.MODE_PRIVATE)

    var anim: PressAnim
        get() = runCatching { PressAnim.valueOf(sp.getString("anim", "SHRINK")!!) }.getOrDefault(PressAnim.SHRINK)
        set(v) { sp.edit().putString("anim", v.name).apply() }

    /** 0 = off, 1 = light, 2 = medium, 3 = strong. */
    var vibration: Int
        get() = sp.getInt("vib", 2).coerceIn(0, 3)
        set(v) { sp.edit().putInt("vib", v).apply() }

    var turboEnabled: Boolean
        get() = sp.getBoolean("turbo", false)
        set(v) { sp.edit().putBoolean("turbo", v).apply() }

    /** One full press (down + up) every this many milliseconds. */
    var turboMs: Int
        get() = sp.getInt("turbo_ms", 100).coerceIn(40, 400)
        set(v) { sp.edit().putInt("turbo_ms", v.coerceIn(40, 400)).apply() }
}

/** Short vibration on presses, if this phone has a vibrator. */
class Haptics(ctx: Context, private val cfg: Settings) {
    @Suppress("DEPRECATION")
    private val vib: Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
        else ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    val supported: Boolean get() = vib?.hasVibrator() == true

    fun tap() {
        val v = vib ?: return
        val level = cfg.vibration
        if (level == 0 || !v.hasVibrator()) return
        val ms = when (level) { 1 -> 12L; 2 -> 20L; else -> 35L }
        val amp = when (level) { 1 -> 60; 2 -> 130; else -> 255 }
        v.vibrate(VibrationEffect.createOneShot(ms, if (v.hasAmplitudeControl()) amp else VibrationEffect.DEFAULT_AMPLITUDE))
    }

    /** Two quick pulses, used when turbo is switched on or off. */
    fun toggle() {
        val v = vib ?: return
        if (cfg.vibration == 0 || !v.hasVibrator()) return
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 25, 50, 25), -1))
    }
}
