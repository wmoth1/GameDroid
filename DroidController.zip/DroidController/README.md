# DroidController

Turns an Android phone into a Bluetooth game controller. Bluetooth only: the app has no network permission. The other device (phone, tablet, PC) sees a gamepad
and needs nothing installed.

## Build

Open this folder in Android Studio (Koala or newer), or push it to GitHub and let the **Build** workflow
(`.github/workflows/build.yml`) produce the APK: Actions tab, open the run, download *DroidController-debug-apk*.
Needs Android 9 (API 28) or newer on the controller phone.

## Use

1. Pick a profile, then **1. Turn on Bluetooth gamepad**, **2. Make this phone discoverable**.
2. On the other device, pair this phone in Bluetooth settings as a game controller. If it doesn't connect by
   itself, press **3. Connect to a paired device**.
3. **Start controller**. A "● Connected" banner shows for a few seconds once the link is up.

## Profiles and the layout editor

Built in: **Xbox**, **PlayStation**, **Switch** (full on-screen pads with that console's layout and labels) and
**Racing (tilt)** (almost empty screen: tilt steers, big left/right pedals, volume keys = A and B).

**Edit layout & mapping** opens the controller in edit mode. Nothing is added, every control already exists:

- **Drag** to move a control, **pinch** (or − / +) to resize it.
- **Remap** picks what it sends: any gamepad button, trigger, stick or D-pad. A stick can act as the D-pad and
  the D-pad can act as a stick.
- **Hide / Show** removes controls you don't need (hidden ones show dashed in the editor).
- **Motion & keys** maps tilt and the volume keys, which have no spot on the screen.
- **Look** switches Xbox / PlayStation / Switch labels and colours. **Reset** restores the starting layout.
- **Save as…** keeps a copy under a new name. Changes are saved as you go.

In play mode a 3-finger tap recalibrates tilt.

## Skins, effects, turbo, macros, vibration

- **Look** (main screen, or Look in the editor): Xbox, PlayStation, Switch, **Retro (SNES)**, **Neon**, **Minimal**,
  **Terminal**.
- **Animation**: what a button does when pressed. None, Shrink, Glow, Ripple, Bounce.
- **Vibration**: Off / Light / Medium / Strong. The phone vibrates when you touch a control. Only shown if the phone has a
  vibrator. It is touch feedback on the phone only; games cannot make the phone rumble.
- **Turbo**: switch it on in the app and set the speed (one press every N ms). In game, **hold** the button you want
  and tap the **TURBO** button (hidden by default: Edit layout, tap TURBO, Show). Tap again while holding to turn it off.
  Turbo buttons show a small yellow T.
- **Macros**: Record on the main screen starts the controller in recording mode. Recording begins at your first
  input; sticks, tilt and buttons are all captured. Stop & save (or Back) ends it. Then map any button, or a volume
  key, to **Macro 1-4** with Remap, or show the hidden **M1-M4** buttons. Press a macro button to play it,
  press again to stop it.

## What the other device sees

A generic Bluetooth gamepad with the Xbox One S button layout. Android does not let apps set the vendor and product
ID, so it is not literally an Xbox controller. It works for Android games and most PC games (DirectInput, SDL, Steam
Input). Games that only accept XInput can be helped with Steam Input. Consoles and iPhone/iPad do not accept it.
Some phone makers block Bluetooth gamepad mode.

## Files

- `Model.kt` buttons, controls, profiles, what each control can send
- `ProfileStore.kt` saved profiles and the built-in layouts
- `BtHid.kt` Bluetooth gamepad (descriptor, registration, reports)
- `ControllerView.kt` draws a layout; plays it or edits it
- `ControllerActivity.kt` play screen and tilt. `EditorActivity.kt` layout editor
- `Settings.kt` (animation, vibration, turbo options and haptics), `Macros.kt` (macro slots)
- `MainActivity.kt`, `Skins.kt` (skin colours and labels), `Ui.kt`
